
import streamlit as st 

st.set_page_config(
    page_title='Home',
    page_icon=':gem:'
)

st.title('Aplicación de Predicción de Diamantes')
st.markdown('<p class="center">Bienvenidos al fascinante mundo del estudio de los diamantes.</p>', unsafe_allow_html=True)
st.write(':gem: :gem: :gem:    :gem: :gem: :gem: :gem: :gem: :gem::gem: :gem: :gem: :gem: :gem: :gem: :gem: :gem: :gem: :gem: :gem: :gem::gem: :gem:')
st.markdown('<p class="center">Aquí podrás explorar los datos y predecir el precio y el corte de los diamantes.</p>', unsafe_allow_html=True)

# Imagen de un diamante para hacerla más atractiva
st.image("Portada_ejer_7.png")#

if st.button('Acerca de los Diamantes', key='acerca', type='primary'):
    st.switch_page('pages/Acerca_de.py')

st.header('Navegación')

col0, col1, col2, col3, col4 = st.columns(5)
# He incluido una sección de limpieza de datos porque el csv que uso es el del ejercicio 3, el que contenía ? y nan y ceros en x y z
with col0:
    if st.button("Carga y limpieza de datos", key='carga', type='primary'):
        st.switch_page('pages/0_Carga_y_limpieza.py')
        
with col1:
    if st.button('Mi exploración de los Datos', key='exploracion', type='primary'):
        st.switch_page('pages/1_EDAs.py')

with col2:
    if st.button('Explora tú mismo los Datos, Filtrando', key='filtros', type='primary'):
        st.switch_page('pages/2_EDAs_filtros.py')

with col3:
    if st.button('Ir a Regresión', key='regresion', type='primary'):
        st.switch_page('pages/3_Regresion.py')
   
with col4:
    if st.button('Ir a Clasificación', key='clasificacion', type='primary'):
        st.switch_page('pages/4_Clasificacion.py')
