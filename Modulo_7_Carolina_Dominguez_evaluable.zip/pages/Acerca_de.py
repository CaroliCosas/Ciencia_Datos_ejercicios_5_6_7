import streamlit as st

st.set_page_config(
    page_title='Aplicación de Predicción de Diamantes',
    page_icon=':gem:'
)
# Estilos CSS personalizados
st.markdown("""
    <style>
    .big-font {
        font-size:30px !important;
        font-weight: bold;
    }
    .center {
        display: flex;
        justify-content: center;
    }
    .expander-header {
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)

st.title('	:eyes: Aplicación de Predicción de Diamantes')
st.markdown('<p class="center">Bienvenido a la aplicación de predicción de diamantes. Aquí puedes explorar los datos, predecir el precio y predecir el corte de los diamantes.</p>', unsafe_allow_html=True)

st.header('Acerca de esta Aplicación')

st.subheader('Introducción y Propósito')
st.write('Esta aplicación utiliza el dataset "diamonds" para explorar y predecir características de los diamantes. Permite a los usuarios visualizar datos, predecir precios y clasificar cortes.')

st.subheader('Funcionalidades Principales')
st.write('- **Exploración de Datos (EDA):** Visualización interactiva de datos con filtros.')
st.write('- **Predicción de Precio (Regresión):** Predicción del precio de un diamante basado en sus características.')
st.write('- **Predicción de Corte (Clasificación):** Clasificación del corte de un diamante.')
# Estándares de la Industria:
#Añade información sobre los estándares de la industria para la clasificación de diamantes (por ejemplo, las 4 C: carat, cut, color, clarity).

st.header('Veamos las Columnas Numéricas del Dataset')
    
with st.expander('**carat:**'):
    st.markdown('* **Descripción:** Representa el peso del diamante en quilates.')
    st.markdown('* **Unidades:** Quilates (1 quilate = 0.2 gramos).')
    st.markdown('* **Impacto:** El peso tiene un impacto significativo en el precio del diamante. Diamantes más grandes (mayor quilate) son más valiosos, pero el precio no crece linealmente.')
    st.markdown('* **Conversión:** Pasar de quilates a gramos: 1 quilate = 0.2 gramos.')

with st.expander('**depth:**'):
    st.markdown('* **Descripción:** Proporción de profundidad del diamante.')
    st.markdown('* **Cálculo:** `depth = (z / ((x + y) / 2)) * 100`')
    st.markdown(r'$depth = \frac{z}{\frac{x + y}{2}} \times 100$')
    st.markdown('* **Significado:** Es un porcentaje que describe cuán profundo es el diamante en relación con su ancho promedio.')
    st.markdown('* **Profundidad Ideal:** La profundidad ideal para un diamante ronda el 60%-62%.')

with st.expander('**table:**'):
    st.markdown('* **Descripción:** Representa el ancho de la parte superior del diamante (la "tabla") como porcentaje del ancho promedio del diamante.')
    st.markdown('* **Unidades:** Porcentaje.')
    st.markdown('* **Impacto:** Una tabla ideal se encuentra entre 53%-57% para maximizar la reflexión de la luz.')

with st.expander('**price:**'):
    st.markdown('* **Descripción:** Precio del diamante en dólares estadounidenses (USD).')
    st.markdown('* **Impacto:** Determinado por una combinación de peso (carat), calidad del corte (cut), color y claridad (clarity).')
    st.markdown('* **Nota:** Combinar estos 3 parámetros y ver cómo cambia el precio.')

with st.expander('**x, y, z:**'):
    st.markdown('* **Descripción:** Dimensiones físicas del diamante en milímetros:')
    st.markdown('*     x: Longitud.')
    st.markdown('*     y: Ancho.')
    st.markdown('*     z: Profundidad.')

with st.expander('**price_per_carat:**'):
    st.markdown('* **Descripción:** Precio por quilate del diamante.')
    st.markdown('* **Cálculo:** `price_per_carat = price / carat`')

st.header('Y ahora, las Columnas Categóricas')

with st.expander('**cut:**'):
    st.markdown('* **Descripción:** La calidad del corte del diamante.')
    st.markdown('* **Categorías:**')
    st.markdown('*     Fair (Pobre)')
    st.markdown('*     Good (Bueno)')
    st.markdown('*     Very Good (Muy Bueno)')
    st.markdown('*     Premium (Premium)')
    st.markdown('*     Ideal (Ideal)')
    st.markdown('* **Impacto:** La calidad del corte determina lo bien que el diamante refleja la luz. Ideal es el mejor corte, maximizando el brillo, mientras que Fair refleja menos luz.')

with st.expander('**color:**'):
    st.markdown('* **Descripción:** El color del diamante, clasificado desde D (mejor, incoloro) hasta J (peor, amarillo tenue).')
    st.markdown('* **Categorías:**')
    st.markdown('*     D (Mejor, incoloro)')
    st.markdown('*     E, F, G, H, I, J (Peor, más amarillo tenue)')
    st.markdown('* **Impacto:** Los diamantes más incoloros (D-F) son más valiosos. Los colores más bajos (H-J) tienen tonos amarillentos.')
    st.markdown('* **Nota:** Verlos en figuras.')

with st.expander('**clarity:**'):
    st.markdown('* **Descripción:** La claridad del diamante, con valores que describen la cantidad de inclusiones o defectos.')
    st.markdown('* **Categorías:**')
    st.markdown('*     IF (Internamente Impecable)')
    st.markdown('*     VVS1, VVS2 (Muy, muy pequeñas inclusiones)')
    st.markdown('*     VS1, VS2 (Muy pequeñas inclusiones)')
    st.markdown('*     SI1, SI2 (Pequeñas inclusiones)')
    st.markdown('*     I1 (Inclusions visibles)')
    st.markdown('* **Impacto:** La claridad mide las imperfecciones internas y externas. Los grados más altos (IF) son más valiosos.')

#Contexto Adicional:
#Para las columnas numéricas, menciona los rangos típicos de valores y cómo se distribuyen en el dataset.
#Para las columnas categóricas, explica cómo se clasifican los diamantes según los estándares de la industria.


st.header('Relaciones Clave')

st.subheader('Relación entre Peso y Precio:')
st.markdown('El precio aumenta exponencialmente con el peso (carat), especialmente para pesos superiores a 1 quilate.') #(TO DO comprobarlo)')

st.subheader('Influencia del Corte, Color y Claridad:')
st.markdown('* Un corte de alta calidad puede aumentar significativamente el brillo, lo que lo hace más atractivo incluso con colores más bajos (H, I).')
st.markdown('* Un diamante con buen color (D-F) y claridad (IF, VVS) tiene mayor valor.')
st.markdown("* Un corte 'Ideal' maximiza la refracción de la luz y el brillo en comparación con un corte 'Fair'.")
st.markdown('La interacción entre estas variables puede ser compleja. Por ejemplo, un diamante con claridad VS1 y color G puede tener un precio diferente a uno con claridad SI1 y color E, incluso si tienen el mismo peso.')

st.subheader('Dimensiones (x, y, z) y Proporciones:')
st.markdown('Las proporciones ideales de un diamante maximizan su apariencia visual y reflejan más luz.')

st.header('Análisis Clave que se Pueden Realizar')

st.subheader('Distribución de Precios:')
st.markdown('Identificar los rangos más comunes de precios y analizar los factores que los afectan.')

#¿Cuál es el rango de precios más común para los diamantes con corte 'Ideal'?"

st.subheader('Comparar Claridad y Color:')
st.markdown('¿Cómo se distribuyen los precios para diferentes combinaciones de claridad y color?')

st.subheader('Volumen del Diamante:')
st.markdown('Crear una nueva columna para el volumen (x * y * z) y analizar su relación con el precio.') #(TO DO)')

st.subheader('Correlaciones:')
st.markdown('Calcular las correlaciones entre variables numéricas, como carat, price, y depth.') # (TO DO comprobar que se ha hecho)')
#proporciona ejemplos específicos de correlaciones fuertes o débiles entre variables.
#existe una fuerte correlación positiva entre 'carat' y 'price'.
#un diamante con alta claridad pero bajo color puede tener un precio diferente a uno con bajo claridad pero alto color.

st.subheader('Análisis de Valores Atípicos:')
st.markdown('Identificar diamantes cuyo precio o dimensiones se desvían significativamente.') #(TO DO dar la fila completa de estos diamantes)')
#librerias se pueden utilizar para realizar estos calculos.

st.header('Metodología y Técnicas')
st.write('Se utilizaron pipelines de Scikit-learn para preprocesar los datos y entrenar modelos de regresión y clasificación. Las librerías principales incluyen Pandas, Scikit-learn, Streamlit, etc.')

st.header('Información del Modelo')
st.write('Los modelos se entrenaron en un conjunto de datos preprocesado y se serializaron para su uso en esta aplicación.')
#para la distribución de precios, menciona si se utilizarán histogramas, diagramas de caja, etc.
st.header('Autor y Contacto')
st.write('Esta aplicación fue desarrollada por Carolina Domínguez Cerdeña.')
st.write('Puedes encontrar más proyectos en :')
st.write('https://github.com/CaroliCosas ')   
st.write('https://www.linkedin.com/in/carolinadominguezcerde%C3%B1a?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app].')

# st.subheader('Recursos Adicionales')
# st.write('- [Dataset Diamonds](URL del dataset)')
# st.write('- [Documentación de Streamlit](URL de la documentación)')