
import streamlit as st 
import seaborn as sns
import pandas as pd 
import plotly.express as px
import matplotlib.pyplot as plt
import io
# import numpy as np 
# import altair as alt

st.set_page_config(
    page_title='EDAs',
    page_icon=':bar_chart:'
)
st.markdown("""
    <style>
    .big-font {
        font-size:30px !important;
        font-weight: bold;
    }
    .center {
        display: flex;
        justify-content: center;
    }
    .button {
        background-color: #f0f2f6;
        border: none;
        color: black;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 12px;
    }
    .button:hover {
        background-color: #e2eaf1;
    }
    </style>
""", unsafe_allow_html=True)

if st.button('Volver a Home'): # opcional poder volver a inicio
    st.switch_page('Home.py')

st.title('Página 1 - :bar_chart: EDAs')
st.write('Vamos a exponer los resultados de una muesta de 5.000 filas del dataset, ya limpio, para no hacerlo muy pesado.')    
    
# Carga de datos directa
#@st.cache_data
def load_df_diamonds_muestra():
    return pd.read_csv('data/diamonds_cleaned.csv').sample(5000)

def df_info(df):  
    st.write("*Información del dataset:*")
    buffer = io.StringIO()
    df.info(buf=buffer)
    s = buffer.getvalue()
    st.text(s)

st.write('*********************************************************************')  
df = load_df_diamonds_muestra()
st.write('Te presento el dataframe de Diamantes, con el que vamos a trabajar')
st.dataframe(df)
st.write('Y la información de la muestra, para que conozcas el tipo da datos que tenemos:')
st.write('\n')
df_info(df) 
    
#####################################################################   
st.header('1. Gráficos univariantes')
st.subheader('Histograma de distribución de precios con KDE, con escala logarítmica, Distribución de la Calidad del Corte y Algunos gráficos de violín y boxplot')

try:   
    with st.expander('Histograma de distribución de precios (seaborn)'):
        fig_hist, ax_hist = plt.subplots(figsize=(8, 6))
        sns.histplot(df['price'], bins=30, ax=ax_hist, kde=True)
        ax_hist.set_title('Histograma de Precios (Seaborn)')
        st.pyplot(fig_hist)
      
    with st.expander('Histograma con escala logarítmica'):
        fig_hist_log, ax_hist_log = plt.subplots(figsize=(6, 4))
        sns.histplot(df['price'], kde=True, ax=ax_hist_log, log_scale=True)
        ax_hist_log.set_title('Histplot del Precio (Escala Logarítmica)')
        st.pyplot(fig_hist_log)   
                  
    with st.expander('Distribución de la Calidad del Corte'):
        fig = px.bar(df['cut'].value_counts(), title='Distribución de la Calidad del Corte')
        st.plotly_chart(fig, key=f'scatter_cut')
        #st.plotly_chart(fig, key=f'scatter_cut' , selection_mode='box' , on_select='rerun')

    #numeric_features = df.dtypes[df.dtypes != object].index
    numeric_features = ['carat', 'price', 'x']
    with st.expander('Gráficos de violín y boxplot'):
        for feature in numeric_features:
            st.subheader(f"Visualización de {feature}")
            fig, axes = plt.subplots(1, 2, figsize=(10, 5))
            sns.violinplot(x=feature, data=df, ax=axes[0])
            axes[0].set_title(f"Violin Plot de {feature}")
            sns.boxplot(x=feature, data=df, ax=axes[1])
            axes[1].set_title(f"Box Plot de {feature}")
            st.pyplot(fig)
except:
    st.write('no se pueden hacer figuras')
#####################################################################   

st.header('2. Gráficos bivariantes')
st.subheader('Verás un scatter más completo en la siguiente sección')
try:
    with st.expander('Joint PLots'):
        fig_join = sns.jointplot(x='carat', y='price', data=df, kind='scatter', hue='color', palette='viridis')
        plt.grid()
        st.pyplot(fig_join)
 
except:
    st.write('no se pueden hacer figuras')
#####################################################################   

st.header('3. Gráficos multivariantes')
st.subheader('Heatmap, Pairplot, Scatter con hue y Gráfico de Mosaico')

try:   
    with st.expander('Heatmap (Seaborn)'):
        corr = df.corr(numeric_only=True)
        fig_heatmap, ax_heatmap = plt.subplots(figsize=(10, 8))
        sns.heatmap(corr, annot=True, cmap='coolwarm', ax=ax_heatmap)
        ax_heatmap.set_title('Mapa de Calor de Correlaciones (Seaborn)')
        st.pyplot(fig_heatmap)

    with st.expander('Pair Plot (Seaborn)'):
        pair_plot = sns.pairplot(df[['carat', 'price', 'depth', 'table']])
        st.pyplot(pair_plot)
 
    with st.expander('Scatter Plot con Hue (Seaborn)'):
        fig_scatter_hue, ax_scatter_hue = plt.subplots(figsize=(8, 6))
        sns.scatterplot(x='carat', y='price', hue='cut', data=df, ax=ax_scatter_hue)
        ax_scatter_hue.set_title('Quilates vs. Precio con Hue (Seaborn)')
        st.pyplot(fig_scatter_hue)

    # with st.expander('Gráficos de Dispersión 3D'):
    #     fig = px.scatter_3d(df, x='carat', y='depth', z='price', color='cut')
    #     st.plotly_chart(fig, key='3D')

    # with st.expander('Gráficos de Coordenadas Paralelas'):
    #    fig = px.parallel_coordinates(df[['carat', 'depth', 'table', 'price']], color='price')
    #    st.plotly_chart(fig, key='parallel')

    with st.expander('Gráficos de Mosaico (Treemaps)'):
        fig = px.treemap(df, path=['cut', 'color', 'clarity'], values='price')
        st.plotly_chart(fig, key='treemap')

except:
    st.write('No funciona') 
    
############################################################   
st.header("4. Agrupamiento y Visualización de Datos")

try:        
    with st.expander("Agrupar y Visualizar"):
        # Agrupamiento y cálculo de estadísticas
        grouped = df.groupby(['cut', 'color', 'clarity']).agg({
            'price': ['mean', 'max', 'min'],
            'carat': ['mean', 'max', 'min'],
            'depth': ['mean', 'max', 'min']
        }).reset_index()

        grouped.columns = [
            'cut', 'color', 'clarity',
            'price_mean', 'price_max', 'price_min',
            'carat_mean', 'carat_max', 'carat_min',
            'depth_mean', 'depth_max', 'depth_min'
        ]

        #Ordenamiento
        grouped_sorted = grouped.sort_values(by='price_mean', ascending=False)

        st.write("DataFrame Agrupado y Ordenado por corte, color y claridad:")
        st.dataframe(grouped_sorted)

        st.subheader('Visualización 1: Precio promedio por tipo de corte y color')
        plt.figure(figsize=(10, 6))
        sns.barplot(data=grouped, x='cut', y='price_mean', hue='color', palette='viridis')
        plt.title("Precio Promedio por Tipo de Corte y Color")
        plt.xlabel("Tipo de Corte")
        plt.ylabel("Precio Promedio (USD)")
        plt.legend(title='Color')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        st.pyplot(plt)

        st.subheader('Visualización 2: Precio promedio por color y tipo de corte')
        plt.figure(figsize=(10, 6))
        sns.barplot(data=grouped, x='color', y='price_mean', hue='cut', palette='viridis')
        plt.title("Precio Promedio por Color y Tipo de Corte")
        plt.xlabel("Color")
        plt.ylabel("Precio Promedio (USD)")
        plt.legend(title='Tipo de Corte')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        st.pyplot(plt)

except:
    st.write('No se puede')
# #####################################################################   

# Me encantaría poner opciones para descargar todas las figuras, con la fecha etc
