import streamlit as st 
import pandas as pd
import joblib
import io

st.set_page_config(
    page_title='Regresión',
    page_icon=':chart_with_upwards_trend:'
)
if st.button('Volver a inicio'): # opcional poder volver a inicio
    st.switch_page('Home.py')

st.title('Página 3 - :chart_with_upwards_trend: Regresión')
st.header('1. Carga de datos')
   
#@st.cache_resource
def load_scikit_model():
    return joblib.load('models/pipeline_regresion.joblib')

model = load_scikit_model()

def df_info(df):  
    st.write("*Información del dataset:*")
    buffer = io.StringIO()
    df.info(buf=buffer)
    s = buffer.getvalue()
    st.text(s)
    
df = pd.read_csv('diamonds_cleaned.csv')
df.info()

with st.expander('información del tipo de variables del dataset'):
    df_info(df)
    
with st.expander("El dataframe:"):
    st.write('Si no hace clic muesta una tabla con 5 filas, si hace clic muestra todo el DataFrame')
    clicked = st.button('Mostrar dataframe completo')
    if not clicked:
        st.table(df.head())
    else: 
        st.dataframe(df, use_container_width=True)

# Categorías y Columnas Numéricas
categorical_cols = ["cut", "color", "clarity"]
numerical_cols = ["carat", "depth", "table", "x", "y", "z"]

st.header('2. Formulario predicción')
st.markdown('Elige los datos para la predicción del precio. Cuando termines, pulsa el botón que hay al final, para Generar la predicción')
st.write('******************************************************')
with st.form("diamonds_form"):
    # Filtros para columnas categóricas
    st.write('Vamos a definir el orden de importancia para cada columna categórica:')
    st.markdown('> _(Recuerda que tienes más información en la página **Acerca de**)_')
    st.write('******************************************************')

    cut_order = ['Fair', 'Good', 'Very Good', 'Premium', 'Ideal']
    color_order = ['J', 'I', 'H', 'G', 'F', 'E', 'D']
    clarity_order = ['I1', 'SI2', 'SI1', 'VS2', 'VS1', 'VVS2', 'VVS1', 'IF']
     
    cut_options = [c for c in cut_order if c in df['cut'].unique()]
    color_options = [c for c in color_order if c in df['color'].unique()]
    clarity_options = [c for c in clarity_order if c in df['clarity'].unique()]

    st.write(f'**cut** de peor a mejor calidad: {cut_order}')
    cut_option = st.selectbox('Elige Calidad del Corte', options=cut_options)
    st.write(f'**color** de peor a mejor color: {color_order}')
    color_option = st.selectbox('Elige Color', options=color_options)
    st.write(f'**clarity** de peor a mejor claridad: {clarity_order}')
    clarity_option = st.selectbox('Elige Claridad', options=clarity_options)
   
    # cut_option = st.selectbox('Elige Calidad del Corte', options=df['cut'].unique().tolist())
    # color_option = st.selectbox('Elige Color', options=df['color'].unique().tolist())
    # clarity_option = st.selectbox('Elige Claridad', options=df['clarity'].unique().tolist())

    # Filtros para columnas numéricas
    carat_option = st.slider('Elige Quilates', min_value=float(df['carat'].min()), max_value=float(df['carat'].max()), value=df['carat'].mean(), step=0.01)
    depth_option = st.slider('Elige Profundidad', min_value=float(df['depth'].min()), max_value=float(df['depth'].max()), value=df['depth'].mean(), step=0.01)
    table_option = st.slider('Elige Tabla', min_value=float(df['table'].min()), max_value=float(df['table'].max()), value=df['table'].mean(), step=0.01)
    x_option = st.slider('Elige X', min_value=float(df['x'].min()), max_value=float(df['x'].max()), value=df['x'].mean(), step=0.01)
    y_option = st.slider('Elige Y', min_value=float(df['y'].min()), max_value=float(df['y'].max()), value=df['y'].mean(), step=0.01)
    z_option = st.slider('Elige Z', min_value=float(df['z'].min()), max_value=float(df['z'].max()), value=df['z'].mean(), step=0.01)

    boton_enviar = st.form_submit_button("Generar predicción")

    if boton_enviar:
        #X_new = pd.DataFrame({
        filter = {
            'carat': [carat_option],
            'cut': [cut_option],
            'color': [color_option],
            'clarity': [clarity_option],
            'depth': [depth_option],
            'table': [table_option],
            'x': [x_option],
            'y': [y_option],
            'z': [z_option]                              
        }
        X_new = pd.DataFrame(filter)
        st.write('Elegiste las siguientes opciones para hacer tu predicción:')
        st.dataframe(X_new)
        # ojo, este orden tiene que respeta el orden de columnas con el que hemos entrenado al modelo
        # lo comprobaré con el orden del dataframe?
        #df_info(X_new)
        price_mean = df['price'].mean() # precio medio de todo el dataset
        
        prediccion = model.predict(X_new)[0] 
        # esta prediccion se podría guardar en base de datos junto a los datos introducidos
        st.write(prediccion)
        delta_value = prediccion - price_mean
        
        col1, col2 = st.columns(2)
        col1.metric('Precio estimado (predicción)', value=f'{prediccion:.2f} $', delta=f'{delta_value:.2f} $')
        col2.metric('Precio medio', value=f'{price_mean:.2f} $')
