
import streamlit as st 
import seaborn as sns
import pandas as pd 
import plotly.express as px
import matplotlib.pyplot as plt
import io
import numpy as np 
from scipy import stats

st.set_page_config(
    page_title='Carga y Limpieza de Datos',
    page_icon=':bar_chart:'
)
# Estilos CSS personalizados para mejorar la apariencia
st.markdown("""
    <style>
    .big-font {
        font-size:30px !important;
        font-weight: bold;
    }
    .center {
        display: flex;
        justify-content: center;
    }
    .button {
        background-color: #f0f2f6;
        border: none;
        color: black;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 12px;
    }
    .button:hover {
        background-color: #e2eaf1;
    }
    </style>
""", unsafe_allow_html=True)

st.title('Página 0 - Carga y limpieza de datos')

if st.button('Volver a Home'): # opcional poder volver a inicio
    st.switch_page('Home.py')

st.header('1. Carga de datos')
st.write('Te muestro el poceso de limpieza de los datos, por si es de tu interés.')
st.write('Pero no te preocupes, se hace automáticamente y se guarda el resultado en otro archvo CSV.')
st.write('Analizando el dataset: diamonds.csv.')
        
# Carga de datos directa
def load_df_diamonds():
    return pd.read_csv('Data/diamonds.csv')
    st.success('Dataset cargado con éxito!')

def valores_nulos():
    st.markdown("*Número de valores nulos por columna:*")
    st.dataframe(df.isnull().sum().to_frame(name="Valores Nulos"))

def df_info(df):  
    st.write("*Información del dataset:*")
    buffer = io.StringIO()
    df.info(buf=buffer)
    s = buffer.getvalue()
    st.text(s)
    
def quita_nan(df):
    # Función para buscar filas donde hay un texto específico
    columnas_no_procesadas = []
    st.write('------------------------------------')
    for i in df.columns:
        st.write('\n************************************')
        st.write(f"Procesando columna: {i}")
        if df[i].dropna().empty:
            st.write(f"La columna {i} está completamente vacía. No se puede calcular la asimetría.")
            columnas_no_procesadas.append((i, "Columna completamente vacía"))
        if df[i].dtype in [np.float64, np.float32, np.float16, np.int64, np.int32, np.int16]:
            st.write(f"La columna {i} es numérica")
            try:
                skewness = stats.skew(df[i].dropna())
                st.write(f"Asimetría de {i}: {skewness}")
                if skewness > 1:
                    mediana = df[i].median()
                    df[i].fillna(mediana, inplace=True)
                    st.write(f"Rellenando nulos en {i} con la mediana: {mediana}")
                else:
                    media = df[i].mean()
                    df[i].fillna(media, inplace=True)
                    st.write(f"Rellenando nulos en {i} con la media: {media}")
            except Exception as e:
                st.write(f"Error al procesar la columna {i}: {e}")
                columnas_no_procesadas.append((i, f"Error: {e}"))
        else:
            st.write(f"La columna {i} es de texto")
            try:
                moda = df[i].mode()[0]
                df[i].fillna(moda, inplace=True)
                st.write(f"Rellenando nulos en {i} con la moda: {moda}")
            except Exception as e:
                st.write(f"Error al procesar la columna {i}: {e}")
                columnas_no_procesadas.append((i, f"Error: {e}"))
        df[i].apply(lambda x: isinstance(x, (int, float)) or pd.isnull(x))
    st.write('------------------------------------')
    return columnas_no_procesadas

def busca_filas_que_contengan(df, texto):
    """Busca las filas donde una columna contiene un texto específico y devuelve las filas y sus índices."""
    rows_with_texto_mark = df.isin([texto]).any(axis=1)
    df_rows_with_texto_mark = df[rows_with_texto_mark]
    indices = df_rows_with_texto_mark.index.tolist()

    st.write(f"Filas con valores '{texto}':")
    st.dataframe(df_rows_with_texto_mark)
    st.write('------------------------------------')
    st.write(f"Índices de las filas con valores '{texto}':")
    st.write(indices)

    return df_rows_with_texto_mark, indices

def procesar_columnas_dimension(df):
    columnas = ['x', 'y', 'z']

    for col in columnas:
        st.write('-------------------------------------------')
        st.write(f"Procesando columna: {col}")

        zeros_count = (df[col] == 0).sum()
        st.write(f"Valores cero en {col}: {zeros_count}")

        if zeros_count > 0:
            st.write(f"Calculando medianas grupales para {col}...")
            medians = df.loc[df[col] > 0].groupby(['cut', 'color', 'clarity'])[col].median()
            st.write(f"Medianas calculadas por grupo:\n{medians}")

            st.write(f"Reemplazando valores cero en {col}...")
            st.write('**********************')
            for idx, value in df[df[col] == 0].iterrows():
                group_key = (value['cut'], value['color'], value['clarity'])
                st.write(f"\nFila {idx}: cut={value['cut']}, color={value['color']}, clarity={value['clarity']}, precio={value['price']} USD")
                if group_key in medians:
                    df.at[idx, col] = medians[group_key]
                    st.write(f" - Valor reemplazado con mediana grupal del grupo {group_key}: {medians[group_key]}")
                else:
                    general_median = df.loc[df[col] > 0, col].median()
                    df.at[idx, col] = general_median
                    st.write(f" - Valor reemplazado con mediana general: {general_median}")

            st.write(f"\nTodos los valores cero han sido reemplazados en {col}.")
            st.write('**********************')

        st.write(f"Analizando nulos y asimetría en {col}...")
        if df[col].isna().sum() > 0:
            skewness = stats.skew(df[col].dropna())
            st.write(f"Asimetría de {col}: {skewness}")
            try:
                if skewness > 1:
                    mediana = df[col].median()
                    df[col].fillna(mediana, inplace=True)
                    st.write(f"Rellenando nulos en {col} con la mediana: {mediana}")
                else:
                    media = df[col].mean()
                    df[col].fillna(media, inplace=True)
                    st.write(f"Rellenando nulos en {col} con la media: {media}")
            except Exception as e:
                st.write(f"Error al procesar la columna {col}: {e}")
        st.write('-----------------------------------------------')
    st.write("Procesamiento completado.")
     
try:
    df = load_df_diamonds()
    st.success('Dataset cargado con éxito!')
    
#    Si no se hace clic se muesta una tabla con 5 filas, si se hace clic muestra todo el DataFrame
    clicked = st.button('Si prefieres ver el dataframe completo pulsa')
    if not clicked:
        st.table(df.head())
    else: 
        st.dataframe(df, use_container_width=True)
        
    with st.expander("Información inicial del dataset:"):
        #st.write('\n************************************')
        df_info(df)
    #st.write('\n************************************')
        
    with st.expander("Información estadística inicial del dataset:"):
        st.write('**- Información estadística:**')
        st.dataframe(df.describe())
    #st.write('\n************************************')

    with st.expander("Dimensiones iniciales del dataset:"):
        st.write("**- Dimensiones del dataset:**")
        st.dataframe(pd.DataFrame([df.shape], columns=['Filas', 'Columnas']))
    #st.write('\n************************************')

    with st.expander("**Nombres de las columnas: Atención, esta información te será muy útil en adelante**"):
        st.dataframe(pd.DataFrame(df.columns, columns=['Nombre de la columna']))
    #st.write('\n************************************')

    st.header('2. Limpieza de los datos')
    
    with st.expander("Veamos si hay valores nulos en las columnas antes de limpiar:"):
        valores_nulos()
    #st.write('\n************************************')

    st.write("¿Hay valores iguales a '?' en el dataset original?:")
    hay_interr = (df == '?').any().any()
    st.write(hay_interr)
    if hay_interr:
        st.write("Como vemos que sí hay, reemplazamos valores '?' por NaN")
        df = df.replace('?', np.nan) 
        #st.write('\n************************************')

    with st.expander('El dataframe queda así:'):
        df_info(df)
    #st.write('\n************************************')
    with st.expander("Valores nulos en las columnas después de limpiar:"):
        valores_nulos()
    #st.write('\n************************************')

    st.write("Número de filas duplicadas:")
    filas_dupl = df.duplicated().sum()
    st.write(filas_dupl)
    if filas_dupl:
        with st.expander("Pulsa para ver las filas duplicadas:"):
            st.dataframe(df[df.duplicated()])

        st.write("Eliminamos las filas duplicadas:")
        df = df.drop_duplicates()
        st.write("Las filas duplicadas han sido eliminadas.")
    
    st.write("Número de filas duplicadas ahora:")
    st.write(df.duplicated().sum())
    #st.write('\n************************************')
    
    st.write("Nuevas dimensiones del dataset:")
    st.dataframe(pd.DataFrame([df.shape], columns=['Filas', 'Columnas']))
    #st.write('\n************************************')

    st.header("2. Ajustes de valores")
               
    st.write("Cambiamos el tipo de las columnas object (que no sean el precio) a categorical")
    df["cut"] = df["cut"].astype("category")
    df["color"] = df["color"].astype("category")
    df["clarity"] = df["clarity"].astype("category")

    st.write("Cambiamos la variable x a float64")
    df["x"] = df["x"].astype("float64") 

    st.write("la columna price viene como object, la pasamos a float32 antes de quitar los nulos.")
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    # Cambiar a float32 para poder hacer gráficas
    df["price"] = df["price"].astype("float32") 
    
    with st.expander('El dataframe queda así:'):
        df_info(df)
        
    with st.expander("Valores nulos en las columnas después:"):
        valores_nulos()
    
    with st.expander('El dataframe queda así:'):
        df_info(df)
    
    with st.expander("Antes de procesar:"):
        st.dataframe(df)
        df_info(df)

    with st.expander("**Procesamos las columnas**"):
        columnas_no_procesadas = quita_nan(df)

    with st.expander("Después de procesar:"):
        df_info(df)
    
    with st.expander("Número de valores nulos por columna:"):
        total_nulos = df.isnull().sum().sum()
        valores_nulos()

    # Verificar si hay valores nulos
    if total_nulos == 0:
        st.subheader("Ahora tenemos valores no nulos en todo el dataframe, pero sigue habiendo ceros donde no debería.")
    else:
        st.subheader("Todavía hay valores nulos en el dataframe")
        
    if columnas_no_procesadas != []:
        st.write("Columnas no procesadas:")
        for columna, error in columnas_no_procesadas:
            st.write(f"Columna: {columna}, Error: {error}")

    with st.expander("comprobamos que hemos quitado los valores '?'"):
        # Llamar a la función para quitar los valores que ya sabemos que hay
        filas_con_texto, indices = busca_filas_que_contengan(df, '?')
    with st.expander("Buscamos valores 0.0 en las columnas de las dimensiones x, y, z"):    
        st.text('----------------------------------------')
        filas_con_texto, indices = busca_filas_que_contengan(df, 0)
 
    with st.expander("¿Quieres buscar filas que contengan un texto específico?"):
        texto_buscar = st.text_input("Introduce el texto a buscar:", '?')
        if st.button("Buscar"):
            filas_con_texto, indices = busca_filas_que_contengan(df, texto_buscar)

    with st.expander("Comprobemos de nuevo el número de valores nulos por columna:"):    
        valores_nulos()
    
    with st.expander("Vamos a procesar las columnas de dimensión con valores 0.0 (x, y, z): {Hecha un vistazo}"):
        #if st.button("Procesar Dimensiones"):
        procesar_columnas_dimension(df)
        ('----------------------------------------')
        st.write("DataFrame después de procesar las dimensiones:")
        st.dataframe(df)
        busca_filas_que_contengan(df, 0.0)

except FileNotFoundError:
    st.error('No se encontró el archivo diamonds.csv. Asegúrate de que esté en la carpeta data.')

except Exception as e:
    st.error(f'Ocurrió un error al cargar el archivo: {e}')


##################################################################
st.header("3. Codificación de Columnas Categóricas")
st.write('Este apartado también te interesa mucho, y contiene figuras!!:')

def plot_counts():
    for feature in df.dtypes[df.dtypes == object].index:
        sns.countplot(y= feature, data= df)
        plt.show()

with st.expander("Ver los valores Únicos en Columnas Categóricas"):
    categorical_columns = df.select_dtypes(include=['object', 'category'])
    for col in categorical_columns.columns:
        st.write('________________________________________________________')
        st.write(f"Hay {len(df[col].unique())} valores únicos en la columna '{col}':")
        st.write(df[col].unique())

        plt.figure(figsize=(10,6))
        sns.countplot(y=col, data=df, order=df[col].value_counts().index, palette='viridis')  # Usar col como eje y y ordenar por frecuencia
        plt.title(f"Conteo de valores en la columna '{col}'")
        plt.xlabel("Conteo")
        plt.ylabel(col)
        st.pyplot(plt)  # Mostrar el gráfico en Streamlit       


####################################################################

# Manejo de valores cero y nulos
df['carat'] = df['carat'].replace(0, 0.0001)  # Reemplazar ceros con 0.0001
df = df.dropna(subset=['price', 'carat'])  # Eliminar filas con nulos en 'price' o 'carat'

# with st.expander("**Calcular Precio**"):
#     st.write("Calcular el precio por quilate")
#     df['price_per_carat'] = df['price'] / df['carat']
#     st.write("Precio por quilate calculado.")

#     st.write("Calcular el precio por gramo")
#     df['price_per_gr'] = df['price_per_carat'] / 0.2
#     st.write("Precio por gramo calculado.")

#     # Redondear los resultados
#     df['price_per_carat'] = df['price_per_carat'].round(2)
#     df['price_per_gr'] = df['price_per_gr'].round(2)

#     st.write("DataFrame con precio por quilate y precio por gramo (primeras 5 filas):")
#     st.dataframe(df.head())
   
st.header("4. Guardar Dataset Limpio")
st.subheader("Guardamos el dataset con otro nombre para cargarlo directamente en las siguientes páginas")

with st.expander("Guardar Dataset Limpio"):
    df.to_csv("Data/diamonds_cleaned.csv", index=False)
    st.success("Dataset guardado como 'diamonds_cleaned.csv' con éxito.")

    # # Opcional: Mostrar un enlace de descarga
    # with open("diamonds_cleaned.csv", "rb") as file:
    #     st.download_button(
    #         label="Descargar Dataset Limpio",
    #         data=file,
    #         file_name="diamonds_cleaned.csv",
    #         mime="text/csv"
    #     )   