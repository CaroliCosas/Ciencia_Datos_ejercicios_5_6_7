
import streamlit as st
import pandas as pd
import joblib
import io

st.set_page_config(
    page_title='Clasificación', 
    page_icon=':chart_with_upwards_trend:'
)
if st.button('Volver a Home'): # opcional poder volver a inicio
    st.switch_page('Home.py')
    
st.title('Página 4 - :chart_with_upwards_trend: Clasificación')
st.header('1. Carga de datos')

def load_scikit_model():
    return joblib.load('models/pipeline_clasificacion.joblib')

def load_label_encoder():
    return joblib.load('models/label_encoder_cut.joblib')

model = load_scikit_model()
label_encoder = load_label_encoder()

def df_info(df):  
    st.write("*Información del dataset:*")
    buffer = io.StringIO()
    df.info(buf=buffer)
    s = buffer.getvalue()
    st.text(s)

df = pd.read_csv('diamonds_cleaned.csv')
df.info()
print(df['cut'].unique())

with st.expander('información del tipo de variables del dataset'):
    df_info(df)
    
with st.expander("**El dataframe:**"):
    st.write('Si no hace clic muesta una tabla con 5 filas, si hace clic muestra todo el DataFrame')
    clicked = st.button('Mostrar dataframe completo')
    if not clicked:
        st.table(df.head())
    else: 
        st.dataframe(df, use_container_width=True)
        
# Categorías y Columnas Numéricas
categorical_cols = ["color", "clarity"]
numerical_cols = ["carat", "depth", "table", "price", "x", "y", "z"]

st.header('2. Formulario predicción')
st.markdown('Elige los datos para la predicción del tipo de corte. Cuando termines, pulsa el botón que hay al final, para Generar la predicción')
st.write('******************************************************')

with st.form("diamonds_form"):
    # Filtros para columnas categóricas
    st.write('Vamos a definir el orden de importancia para cada columna categórica:')
    st.markdown('> _(Recuerda que tienes más información en la página **Acerca de**)_')
    st.write('******************************************************')

    cut_order = ['Fair', 'Good', 'Very Good', 'Premium', 'Ideal']
    color_order = ['J', 'I', 'H', 'G', 'F', 'E', 'D']
    clarity_order = ['I1', 'SI2', 'SI1', 'VS2', 'VS1', 'VVS2', 'VVS1', 'IF']
     
    cut_options = [c for c in cut_order if c in df['cut'].unique()]
    color_options = [c for c in color_order if c in df['color'].unique()]
    clarity_options = [c for c in clarity_order if c in df['clarity'].unique()]

    st.write(f'**color** de peor a mejor color: {color_order}')
    color_option = st.selectbox('Elige Color', options=color_options)
    st.write(f'**clarity** de peor a mejor claridad: {clarity_order}')
    clarity_option = st.selectbox('Elige Claridad', options=clarity_options)

    # color_option = st.selectbox('Elige Color', options=df['color'].unique().tolist())
    # clarity_option = st.selectbox('Elige Claridad', options=df['clarity'].unique().tolist())

    # Filtros para columnas numéricas
    price_filter = st.slider('Elige Precio', min_value=float(df['price'].min()), max_value=float(df['price'].max()), value=df['price'].mean(), step=0.01)
    carat_option = st.slider('Elige Quilates', min_value=float(df['carat'].min()), max_value=float(df['carat'].max()), value=df['carat'].mean(), step=0.01)
    depth_option = st.slider('Elige Profundidad', min_value=float(df['depth'].min()), max_value=float(df['depth'].max()), value=df['depth'].mean(), step=0.01)
    table_option = st.slider('Elige Tabla', min_value=float(df['table'].min()), max_value=float(df['table'].max()), value=df['table'].mean(), step=0.01)
    x_option = st.slider('Elige X', min_value=float(df['x'].min()), max_value=float(df['x'].max()), value=df['x'].mean(), step=0.01)
    y_option = st.slider('Elige Y', min_value=float(df['y'].min()), max_value=float(df['y'].max()), value=df['y'].mean(), step=0.01)
    z_option = st.slider('Elige Z', min_value=float(df['z'].min()), max_value=float(df['z'].max()), value=df['z'].mean(), step=0.01)

    boton_enviar = st.form_submit_button("Generar predicción")

    if boton_enviar:
        #filter = {
        X_new = pd.DataFrame({    
            'carat': [carat_option],
            'color': [color_option],
            'clarity': [clarity_option],
            'depth': [depth_option],
            'table': [table_option],
            'price': [price_filter],
            'x': [x_option],
            'y': [y_option],
            'z': [z_option]                              
        })
        #X_new = pd.DataFrame(filter)
        st.write('Elegiste las siguientes opciones para hacer tu predicción:')
        st.dataframe(X_new)
        # ojo, este orden tiene que respeta el orden de columnas con el que hemos entrenado al modelo
        # lo comprobaré con el orden del dataframe?
        #df_info(X_new)
        
        # prediccion = model.predict(X_new)
        # proba = model.predict_proba(X_new).max() * 100

        # # # Convertir el valor numérico a etiqueta usando el diccionario
        # cut_dicc = {
        #     0: 'Fair',
        #     1: 'Good',
        #     2: 'Very Good',
        #     3: 'Premium',
        #     4: 'Ideal'}
        
        # corte_estimado = cut_dicc[prediccion[0]]
        # st.write(prediccion)

        # col1, col2 = st.columns(2)
        # col1.metric('Corte estimado (prediccion): ', value=corte_estimado)
        # col2.metric('Corte promedio: ', value=f'{proba:.2f} %')

        try:
            # Realizar la predicción numérica
            prediccion_numerica = model.predict(X_new)[0]
            # Decodificar la predicción numérica a etiqueta categórica
            prediccion_etiqueta = label_encoder.inverse_transform([prediccion_numerica])[0]
            # Calcular la probabilidad de la clase predicha
            proba = model.predict_proba(X_new).max() * 100

            # Mostrar los resultados en Streamlit
            col1, col2 = st.columns(2)
            col1.metric('Corte estimado (predicción): ', value=prediccion_etiqueta)
            col2.metric('Probabilidad: ', value=f'{proba:.2f} %')

        except Exception as e:
            st.error(f'Ocurrió un error durante la predicción: {e}')


   




