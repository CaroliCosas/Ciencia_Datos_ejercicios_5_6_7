
import streamlit as st 
import seaborn as sns
import pandas as pd 
import plotly.express as px
import matplotlib.pyplot as plt
import io
#import numpy as np 

st.set_page_config(
    page_title='EDAs con filtrado',
    page_icon=':bar_chart:'
)
if st.button('Volver a Home'): # opcional poder volver a inicio
    st.switch_page('Home.py')

st.title('Página 2 - :bar_chart: Crea tus EDAs')
st.write('Vamos a exponer los resultados de una muesta de 5.000 filas del dataset, ya limpio, para no hacerlo muy pesado.')    
   
# Carga de datos directa
def load_df_diamonds_muestra():
    return pd.read_csv('data/diamonds_cleaned.csv').sample(5000)

def df_info(df):  
    st.write("*Información de la muestra del dataset:*")
    buffer = io.StringIO()
    df.info(buf=buffer)
    s = buffer.getvalue()
    st.text(s)

if 'df' not in st.session_state:
    st.session_state.df = load_df_diamonds_muestra()

df = st.session_state.df

st.write('*********************************************************************')  
st.write('Te recuerdo el dataframe de Diamantes, con el que vamos a trabajar')
st.dataframe(df)
st.write('Y la información de la muestra, para que conozcas el tipo da datos que tenemos:')
st.write('\n')
df_info(df) 

#########################################################    
#####################################################################   
st.header('1. Filtros globales categóricos y numéricos:')
st.subheader('Visualizaciones Interactivas')
st.markdown('Ve a la barra lateral y escoge los rangos de las variables a tu gusto para realizar visualizaciones interactivas. Cuando acabes, pulsa el botón de Filtrar')
st.write('¡Explora los datos y descubre patrones interesantes!')

try:   
    filtered_df = df.copy()

    nombre = st.sidebar.text_input('¿Cómo te llamas?')
    if nombre:
        st.sidebar.success(f'Hola {nombre}!')
            
    with st.sidebar.form('Filtrar los datos'):        
        # Filtros para columnas categóricas
        cut_filter = st.multiselect("Calidad del corte", options=df["cut"].unique(), default=list(df["cut"].unique()), key='cut')
        color_filter = st.multiselect("Color", options=df["color"].unique(), default=list(df["color"].unique()), key='color')
        clarity_filter = st.multiselect("Claridad", options=df["clarity"].unique(), default=list(df["clarity"].unique()), key='clarity')

       # Filtros para columnas numéricas
        price_filter = st.slider('Rango de Precios', min_value=float(df['price'].min()), max_value=float(df['price'].max()), value=(float(df['price'].min()), float(df['price'].max())), key='price')
        carat_filter = st.slider('Rango de Quilates', min_value=float(df['carat'].min()), max_value=float(df['carat'].max()), value=(float(df['carat'].min()), float(df['carat'].max())), key='carat')
        depth_filter = st.slider('Rango de Profundidad', min_value=float(df['depth'].min()), max_value=float(df['depth'].max()), value=(float(df['depth'].min()), float(df['depth'].max())), key='depth')
        table_filter = st.slider('Rango de Tabla', min_value=float(df['table'].min()), max_value=float(df['table'].max()), value=(float(df['table'].min()), float(df['table'].max())), key='table')
        x_filter = st.slider('Rango de X', min_value=float(df['x'].min()), max_value=float(df['x'].max()), value=(float(df['x'].min()), float(df['x'].max())), key='x')
        y_filter = st.slider('Rango de Y', min_value=float(df['y'].min()), max_value=float(df['y'].max()), value=(float(df['y'].min()), float(df['y'].max())), key='y')
        z_filter = st.slider('Rango de Z', min_value=float(df['z'].min()), max_value=float(df['z'].max()), value=(float(df['z'].min()), float(df['z'].max())), key='z')

        # Botón para filtrar el formulario
        boton_filtrar = st.form_submit_button("Filtrar")

        if boton_filtrar:
               
            def apply_numeric_filter(df, column, filter_range):
                return df[(df[column] >= filter_range[0]) & (df[column] <= filter_range[1])]

            def filter_dataframe(df, filters):
                filtered_df = df.copy()
                for column, filter_value in filters.items():
                    if filter_value:
                        if isinstance(filter_value, list):
                            filtered_df = filtered_df[filtered_df[column].isin(filter_value)]
                        elif isinstance(filter_value, tuple):
                            filtered_df = apply_numeric_filter(filtered_df, column, filter_value)
                return filtered_df
            
            filters = {
                'carat': st.session_state.carat,
                'cut': st.session_state.cut,
                'color': st.session_state.color,
                'clarity': st.session_state.clarity,
                'depth': st.session_state.depth,
                'table': st.session_state.table,
                'price': st.session_state.price,
                'x': st.session_state.x,
                'y': st.session_state.y,
                'z': st.session_state.z
            }

            filtered_df = filter_dataframe(df, filters)
            st.write("Datos filtrados:")
        else:
            st.write("Datos sin filtrar:")
            filtered_df = df
            st.write(f"Te has quedado con todo el dataframe de muestra!: {df.shape}.")
        # Cuando el usuario hace clic en el botón "Filtrar", mostramos los datos introducidos
        if boton_filtrar:
            st.write("## Datos introducidos:")
            st.write(f"- **Nombre:** {nombre}")
            st.write(f"- **Calidad del Corte:** {cut_filter}")
            st.write(f"- **Color:** {color_filter}")
            st.write(f"- **Claridad:** {clarity_filter}")
            st.write(f"- **Rango de Precios:** {price_filter}")
            st.write(f"- **Rango de Quilates:** {carat_filter}")
            st.write(f"- **Rango de Profundidad:** {depth_filter}")
            st.write(f"- **Rango de Tabla:** {table_filter}")
            st.write(f"- **Rango de X:** {x_filter}")
            st.write(f"- **Rango de Y:** {y_filter}")
            st.write(f"- **Rango de Z:** {z_filter}")

        #Mostrar datos filtrados
        with st.expander("Revisa tus Datos filtrados:"):
            st.write(f"Te has quedado con un dataframe de dimensiones: {filtered_df.shape}.")
            st.dataframe(filtered_df)
            df_info(filtered_df)

    #####################################################################   
        

except FileNotFoundError:
    st.error('No se encontró el archivo diamonds.csv. Asegúrate de que esté en la carpeta data.')

except Exception as e:
    st.error(f'Ocurrió un error al cargar el archivo: {e}')

#####################################################################   

st.header('2. Gráficos univariantes')
st.subheader('Histograma de distribución de precios con KDE, con escala logarítmica, Distribución de la Calidad del Corte y Algunos gráficos de violín y boxplot')

try:
    with st.expander('Histograma de distribución de precios (seaborn)'):
        fig_hist, ax_hist = plt.subplots(figsize=(8, 6))
        sns.histplot(filtered_df['price'], bins=30, ax=ax_hist, kde=True)
        ax_hist.set_title('Histograma de Precios (Seaborn)')
        st.pyplot(fig_hist)
      
    with st.expander('Histograma con escala logarítmica'):
        fig_hist_log, ax_hist_log = plt.subplots(figsize=(6, 4))
        sns.histplot(filtered_df['price'], kde=True, ax=ax_hist_log, log_scale=True)
        ax_hist_log.set_title('Histplot del Precio (Escala Logarítmica)')
        st.pyplot(fig_hist_log)   
                  
    with st.expander('Distribución de la Calidad del Corte'):
        fig = px.bar(filtered_df['cut'].value_counts(), title='Distribución de la Calidad del Corte')
        st.plotly_chart(fig, key=f'scatter_cut')

    #numeric_features = filtered_df.dtypes[filtered_df.dtypes != object].index
    numeric_features = ['carat', 'price', 'x']

    with st.expander('Gráficos de violín y boxplot de numéricas'):
        for feature in numeric_features:
            st.subheader(f"Visualización de {feature}")
            fig, axes = plt.subplots(1, 2, figsize=(10, 5))
            sns.violinplot(x=feature, data=df, ax=axes[0])
            axes[0].set_title(f"Violin Plot de {feature}")
            sns.boxplot(x=feature, data=df, ax=axes[1])
            axes[1].set_title(f"Box Plot de {feature}")
            st.pyplot(fig)
except:
    st.write('no se pueden hacer figuras')
#####################################################################   

st.header('3. Gráficos bivariantes')
st.subheader('Verás un scatter más completo en la siguiente sección')
try:
    with st.expander('Joint PLots'):
        fig_join = sns.jointplot(x='carat', y='price', data=filtered_df, kind='scatter', hue='color', palette='viridis')
        plt.grid()
        st.pyplot(fig_join)
 
except:
    st.write('no se pueden hacer figuras')
#####################################################################   

st.header('4. Gráficos multivariantes')
st.subheader('Heatmap, Pairplot, Scatter con hue y Gráfico de Mosaico')

try:   
    with st.expander('Heatmap (Seaborn)'):
        corr = filtered_df.corr(numeric_only=True)
        fig_heatmap, ax_heatmap = plt.subplots(figsize=(10, 8))
        sns.heatmap(corr, annot=True, cmap='coolwarm', ax=ax_heatmap)
        ax_heatmap.set_title('Mapa de Calor de Correlaciones (Seaborn)')
        st.pyplot(fig_heatmap)

    with st.expander('Pair Plot (Seaborn)'):
        pair_plot = sns.pairplot(df[['carat', 'price', 'depth', 'table']])
        st.pyplot(pair_plot)
 
    with st.expander('Scatter Plot con Hue (Seaborn)'):
        fig_scatter_hue, ax_scatter_hue = plt.subplots(figsize=(8, 6))
        sns.scatterplot(x='carat', y='price', hue='cut', data=df, ax=ax_scatter_hue)
        ax_scatter_hue.set_title('Quilates vs. Precio con Hue (Seaborn)')
        st.pyplot(fig_scatter_hue)
        
    with st.expander('Gráficos de Mosaico (Treemaps)'):
        fig = px.treemap(df, path=['cut', 'color', 'clarity'], values='price')
        st.plotly_chart(fig, key='treemap')
except:
    st.write('No funciona') 
    
 #####################################################################   
   
st.header("5. Agrupamiento y Visualización de Datos")
try:        
    with st.expander("Agrupar y Visualizar"):
        # Agrupamiento y cálculo de estadísticas
        grouped = filtered_df.groupby(['cut', 'color', 'clarity']).agg({
            'price': ['mean', 'max', 'min'],
            'carat': ['mean', 'max', 'min'],
            'depth': ['mean', 'max', 'min']
        }).reset_index()

        grouped.columns = [
            'cut', 'color', 'clarity',
            'price_mean', 'price_max', 'price_min',
            'carat_mean', 'carat_max', 'carat_min',
            'depth_mean', 'depth_max', 'depth_min'
        ]
        # Ordenamiento
        grouped_sorted = grouped.sort_values(by='price_mean', ascending=False)

        st.write("DataFrame Agrupado y Ordenado por corte, color y claridad:")
        st.dataframe(grouped_sorted)

        st.subheader('Visualización 1: Precio promedio por tipo de corte y color')
        plt.figure(figsize=(10, 6))
        sns.barplot(data=grouped, x='cut', y='price_mean', hue='color', palette='viridis')
        plt.title("Precio Promedio por Tipo de Corte y Color")
        plt.xlabel("Tipo de Corte")
        plt.ylabel("Precio Promedio (USD)")
        plt.legend(title='Color')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        st.pyplot(plt)

        st.subheader('Visualización 2: Precio promedio por color y tipo de corte')
        plt.figure(figsize=(10, 6))
        sns.barplot(data=grouped, x='color', y='price_mean', hue='cut', palette='viridis')
        plt.title("Precio Promedio por Color y Tipo de Corte")
        plt.xlabel("Color")
        plt.ylabel("Precio Promedio (USD)")
        plt.legend(title='Tipo de Corte')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        st.pyplot(plt)

    # # Seleccionar Métricas
    # #metricas = st.multiselect("Seleccionar Métricas", options=["mean", "min", "max"], default=[])
    # metricas = ["mean", "min", "max"]

    # # Categorías y Columnas Numéricas
    # categorical_cols = ["cut", "color", "clarity"]
    # numerical_cols = ["price", "carat", "depth", "table", "x", "y", "z", "volumen", "price_per_carat"]

    # # Crear una figura por cada métrica
    # for metrica in metricas:
    #     with st.expander(f"Gráficos de {metrica.title()} por Categorías"):
    #         fig, axes = plt.subplots(len(categorical_cols), len(numerical_cols), figsize=(18, 12), constrained_layout=True)

    #         # Iterar sobre las categorías y columnas numéricas
    #         for i, categoria in enumerate(categorical_cols):
    #             for j, columna in enumerate(numerical_cols):
    #                 # Agrupar por la categoría actual y calcular la métrica deseada
    #                 grouped = filtered_df.groupby(categoria).agg({columna: metrica}).reset_index()

    #                 # Crear el gráfico en el subplot correspondiente
    #                 sns.barplot(data=grouped, x=categoria, y=columna, ax=axes[i, j], palette="viridis")

    #                 # Configurar el título y las etiquetas
    #                 axes[i, j].set_title(f"{metrica.title()} de {columna.title()} por {categoria.title()}")
    #                 axes[i, j].set_xlabel(categoria.title())
    #                 axes[i, j].set_ylabel(f"{metrica.title()} de {columna.title()}")
    #                 axes[i, j].grid(axis="y", linestyle="--", alpha=0.7)

    #         # Configurar el título general de la figura
    #         plt.suptitle(f"Gráficos de {metrica.title()} por Categorías", fontsize=16, y=1.02)

    #         # Mostrar la figura completa en Streamlit
    #         st.pyplot(fig)    
except:
    st.write('No se puede')
#####################################################################   

st.header('5. Descargar datos')
st.html('<p style="text-align:center">Descarga el dataset original o con los datos filtados</p>')
#st.write(f'Descarga un archivo CSV con los datos actualmente filtrados por especie: {selected_species}, isla: {selected_islands}, género: {selected_genres}, rango de longitud de pico: {bill_length_min, bill_length_max}')
      
col1, col2 = st.columns(2, vertical_alignment='center')
with col1:
    st.download_button(
        'Descargar datos originales',
        data=filtered_df.to_csv(index=False),
        file_name='diamonds_download.csv',
        mime='text/csv'
    )    

with col2:    
    st.download_button(
        'Descargar datos filtrados',
        data=filtered_df.to_csv(index=False),
        file_name='diamonds_filtered_download.csv',
        mime='text/csv'
    )

st.write()
    
    
# #Usar!!   
# container1 = st.container(border=True)
# container1.write('Esto es un texto')
# container1.image('https://placehold.co/600x200', caption='Imagen 600x200')   
# container1.write('Esto es otro texto') 

 